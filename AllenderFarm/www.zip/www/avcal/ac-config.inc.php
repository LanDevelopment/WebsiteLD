<?php
//	 database settings
define("AC_DB_HOST",		"mysql.globalgold.co.uk");
define("AC_DB_NAME",		"alleeo380");
define("AC_DB_USER",		"alleeo380");
define("AC_DB_PASS",		"lacqu593");
define("AC_DB_PREFIX",		"");
//	do not alter these lines
define("AC_ROOT"			, dirname(__FILE__). "/");
define("AC_INLCUDES_ROOT"	, AC_ROOT."ac-includes/");
?>
