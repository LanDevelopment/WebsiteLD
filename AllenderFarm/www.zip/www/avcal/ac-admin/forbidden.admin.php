<?php
$warning.=$lang["warning_no_page_permission"];
?>