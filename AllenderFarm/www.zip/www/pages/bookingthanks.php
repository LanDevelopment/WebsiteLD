
<h2>
	Thank you!
</h2>

<p>
	Thank you very much for booking your holiday at Allender Farm.
	<br>Jane or Jim will contact you to update you about your booking very soon!
</p>

<p>
	Many thanks,
	<br>
	<br>
	<img src="img/icons/leftdaisy.png" alt="flower">
	<span>Jane &amp; Jim Bridges</span>
	<img src="img/icons/rightdaisy.png" alt="flower">
</p>

<div>
	<a href="./node.php">
		<img src="img/circleallender.png" alt="" class="circlelogo">
	</a>
</div>
