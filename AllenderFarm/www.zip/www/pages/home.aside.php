

<?php include 'parts/bookingbox.php'; ?>


<h2>
	Find us!
</h2>

<a href="?p=Location">
	<img src="img/findusmap.jpg" alt="allendermap">
</a>
