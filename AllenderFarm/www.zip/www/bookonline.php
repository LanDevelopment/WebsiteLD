
<div style="max-width:880px;margin:0 auto;">
	<?php include 'parts/bookingbox.php'; ?>

	<div id="accordion" style="display:inline-block;width:50%;">
		<?php
			include 'parts/prices.php';
		?>
	</div>
</div>

<iframe src="/avcal/" id="bookonline-iframe" style="display:block;margin:0 auto">
</iframe>
