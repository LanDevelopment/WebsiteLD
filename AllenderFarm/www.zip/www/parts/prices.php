﻿<!--
	This is where prices go, like this:
	<li>
		7th Jan 2014 - £456.50
	</li>
-->

<h3>
	Primrose
</h3>

<div>
	<table>
		<tr>
			<td>Rental Period  2017</td>
			
			<td>Per Week</td>
		</tr>
		
		
		<tr>
			<td>
				2 January - 3 March
			</td>
			
			<td>
				£ 300
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 March - 7 April
			</td>
			
			<td>
				£ 350
			</td>
		</tr>
		
		
		<tr>
			<td>
				7th April -21 April
			</td>
			
			<td>
				£ 450
			</td>
		</tr>
		
		
		<tr>
			<td>
				21 April - 26 May
			</td>
			
			<td>
				£ 360
			</td>
		</tr>
		
		
		<tr>
			<td>
				26 May - 2 June
			</td>
			
			<td>
				£ 450
			</td>
		</tr>
		
		
		<tr>
			<td>
				2 June - 16 June
			</td>
			
			<td>
				£ 380
			</td>
		</tr>
		
		
		<tr>
			<td>
				16 June - 7 July
			</td>
			
			<td>
				£ 415
			</td>
		</tr>
		
		
		<tr>
			<td>
				7 July - 14 July
			</td>
			
			<td>
				£ 450
			</td>
		</tr>
		
		
		<tr>
			<td>
				14 July - 1 September
			</td>
			
			<td>
				£ 510
			</td>
		</tr>
		
		
		<tr>
			<td>
				1 September - 6 October
			</td>
			
			<td>
				£ 380
			</td>
		</tr>
		
		
		<tr>
			<td>
				6 October - 3rd November
			</td>
			
			<td>
				£ 325
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 November - 23 December
			</td>
			
			<td>
				£ 300
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 December - 5 January
			</td>
			
			<td>
				£ 480
			</td>
		</tr>
		
		
		<tr>
			<td>
				5 January- 5 March
			</td>
			
			<td>
				£ 310
			</td>
		</tr>
		
		
	</table>
</div>

<h3>
	Azalea
</h3>

<div>
	<table>
		<tr>
			<td>
				Rental Period  2017
			</td>
			
			<td>
				Per Week
			</td>
		</tr>
		
		<tr>
			<td>
			 3 January  - 4 March
			</td>
			
			<td>
				£ 350
			</td>
		</tr>
		
		<tr>
			<td>
				4 March - 8 April
			</td>
			
			<td>
				£ 420
			</td>
		</tr>
		
		
		<tr>
			<td>
				8 April - 22 April
			</td>
			
			<td>
				£ 520
			</td>
		</tr>
		
		
		<tr>
			<td>
				22 April - 27 May
			</td>
			
			<td>
				£ 430
			</td>
		</tr>
		
		
		
		<tr>
			<td>
				27 May - 3 June
			</td>
			
			<td>
				£ 535
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 June - 17 June
			</td>
			
			<td>
				£ 490
			</td>
		</tr>
		
		
		<tr>
			<td>
				17 June - 8 July
			</td>
			
			<td>
				£ 510
			</td>
		</tr>
		
		
		<tr>
			<td>
				8 July  - 15 July
			</td>
			
			<td>
				£ 560
			</td>
		</tr>
		
		
		<tr>
			<td>
				15 July - 2 September
			</td>
			
			<td>
				£ 700
			</td>
		</tr>
		
		
		<tr>
			<td>
				2 September - 7 October
			</td>
			
			<td>
				£ 600
			</td>
		</tr>
		
		
		<tr>
			<td>
				7 October - 4 November
			</td>
			
			<td>
				£ 470
			</td>
		</tr>
		
		
		<tr>
			<td>
				4 November - 23 December
			</td>
			
			<td>
				£ 380
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 December - 5 January
			</td>
			
			<td>
				£ 640
			</td>
		</tr>
		
		
		<tr>
			<td>
				5 January - 6 March
			</td>
			
			<td>
				£ 360
			</td>
		</tr>
		
		
		
		
		
	</table>
</div>

<h3>
	Jasmine
</h3>

<div>
	<table>
		<tr>
			<td>
				Rental Period 2016 - 2017
			</td>
			
			<td>
				Per Week
			</td>
		</tr>
		
		<tr>
			<td>
			  3 January  - 4 March
			</td>
			
			<td>
				£ 450
			</td>
		</tr>
		
		<tr>
			<td>
				4 March - 8 April
			</td>
			
			<td>
				£ 490
			</td>
		</tr>
		
		
		<tr>
			<td>
				8 April - 22 April
			</td>
			
			<td>
				£ 680
			</td>
		</tr>
		
		
		<tr>
			<td>
				22 April - 27 May
			</td>
			
			<td>
				£ 575
			</td>
		</tr>
		
		
		<tr>
			<td>
				27 May - 3 June
			</td>
			
			<td>
				£ 680
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 June - 17 June
				
			</td>
			
			<td>
				£ 630
			</td>
		</tr>
		
		
		<tr>
			<td>
				17 June - 8 July
			</td>
			
			<td>
				£ 660
			</td>
		</tr>
		
		
		<tr>
			<td>
				8 July - 15 July
			</td>
			
			<td>
				£ 770
			</td>
		</tr>
		
		
		<tr>
			<td>
				15 July - 2 September
			</td>
			
			<td>
				£ 880
			</td>
		</tr>
		
		
		<tr>
			<td>
				2 September - 7 October
			</td>
			
			<td>
				£ 625
			</td>
		</tr>
		
		
		<tr>
			<td>
				7 October - 4 November
			</td>
			
			<td>
				£ 525
			</td>
		</tr>
		
		
		<tr>
			<td>
				4 November - 23 December
			</td>
			
			<td>
				£ 490
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 December - 5 January
			</td>
			
			<td>
				£ 820
			</td>
		</tr>
		
		
		<tr>
			<td>
				5 January - 6 March
			</td>
			
			<td>
				£ 460
			</td>
		</tr>
		
		
		
		</tr>
	</table>
</div>

<h3>
	Bluebell
</h3>

<div>
	<table>
		<tr>
			<td>
				Rental Period  2017
			</td>
			
			<td>
				Per Week
			</td>
		</tr>
		
		<tr>
			<td>
				3 January  - 5 March
			</td>
			
			<td>
				£ 470
			</td>
		</tr>
		
		<tr>
			<td>
				5 March - 9 April
			</td>
			
			<td>
				£ 500
			</td>
		</tr>
		
		
		<tr>
			<td>
				9 April - 23 April
			</td>
			
			<td>
				£ 700
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 April - 28 May
			</td>
			
			<td>
				£ 600
			</td>
		</tr>
		
		
		<tr>
			<td>
				28 May - 4 June
			</td>
			
			<td>
				£ 725
			</td>
		</tr>
		
		
		<tr>
			<td>
				4 June - 18 June
			</td>
			
			<td>
				£ 680
			</td>
		</tr>
		
		
		<tr>
			<td>
				18 June - 9 July
			</td>
			
			<td>
				£ 690
			</td>
		</tr>
		
		
		<tr>
			<td>
				9 July - 16 July
			</td>
			
			<td>
				£ 810
			</td>
		</tr>
		
		
		<tr>
			<td>
				16 July - 3 September
			</td>
			
			<td>
				£ 910
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 September - 8 October
			</td>
			
			<td>
				£ 820
			</td>
		</tr>
		
		
		<tr>
			<td>
				8 October - 5 November
			</td>
			
			<td>
				£ 675
			</td>
		</tr>
		
		
		<tr>
			<td>
				5 November - 23 December
			</td>
			
			<td>
				£ 550
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 December - 4 January
			</td>
			
			<td>
				£ 850
			</td>
		</tr>
		
		
		
	</table>
</div>

<h3>
	Honeysuckle
</h3>

<div>
	<table>
		<tr>
			<td>
				Rental Period  2017
			</td>
			
			<td>
				Per Week
			</td>
		</tr>	
		
		<tr>
			<td>
				2 January - 3 March
			</td>
			
			<td>
				£ 625
			</td>
		</tr>
		
		<tr>
			<td>
				3 March - 7 April
			</td>
			
			<td>
				£ 700
			</td>
		</tr>
		
		
		<tr>
			<td>
				7 April - 21 April
			</td>
			
			<td>
				£ 835
			</td>
		</tr>
		
		
		<tr>
			<td>
				21 April - 26 May
			</td>
			
			<td>
				£ 720
			</td>
		</tr>
		
		
		<tr>
			<td>
				26 May - 2 June
			</td>
			
			<td>
				£ 950
			</td>
		</tr>
		
		
		<tr>
			<td>
				2 June - 16 June
			</td>
			
			<td>
				£ 900
			</td>
		</tr>
		
		
		<tr>
			<td>
				16 June - 7 July
			</td>
			
			<td>
				£ 925
				
			</td>
		</tr>
		
		
		<tr>
			<td>
				7 July - 14 July
			</td>
			
			<td>
				£ 1080
			</td>
		</tr>
		
		
		<tr>
			<td>
				14 July - 1 September
			</td>
			
			<td>
				£ 1200
			</td>
		</tr>
		
		
		<tr>
			<td>
				1 September - 6 October
			</td>
			
			<td>
				£ 800
			</td>
		</tr>
		
		
		<tr>
			<td>
				6 October - 3 November
			</td>
			
			<td>
				£ 650
			</td>
		</tr>
		
		
		<tr>
			<td>
				3 November - 23 December
			</td>
			
			<td>
				£ 625
			</td>
		</tr>
		
		
		<tr>
			<td>
				23 December - 5 January
			</td>
			
			<td>
				£ 1080
			</td>
		</tr>
		
		
		<tr>
			<td>
				5 January - 8 March
			</td>
			
			<td>
				£ 635
			</td>
		</tr>
		
		
		
		</tr>
	</table>
</div>
